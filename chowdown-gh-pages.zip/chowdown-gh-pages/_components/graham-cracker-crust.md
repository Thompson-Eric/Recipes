---

layout: recipe
title:  "Graham Cracker Crust"
image: graham-cracker-crust.jpg
imagecredit: https://flic.kr/p/atxu75

ingredients:
- 2 cups graham cracker crumbs
- 6 tbs butter (melted)
- 1/3 cup white sugar
- 1 tsp cinnamon

directions:
- pulse graham cracker in food processor or use muddler to crumb in bowl
- combine melted butter, graham cracker crumbs, sugar, and cinnamon in a bowl
- press into pan, forming into crust shape

---

A simple graham cracker crust, perfect for cheesecakes or tarts.