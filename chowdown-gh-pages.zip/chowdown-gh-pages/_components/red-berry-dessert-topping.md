---

layout: recipe
title:  "Red Berry Dessert Topping"
image: red-berry-topping.jpg
imagecredit: https://flic.kr/p/9kczzP

ingredients:
- 1/2 cup raspberries
- 1/2 cup strawberries
- 1/4 white sugar
- 1 squirt honey


directions:
- Dice berries
- Combine all ingredients
- Let rest for 15 mins

---

A simple mash of berries, perfect for a tart or top of cheesecake.