---

layout: recipe
title:  "Smashed Carrots"
image: smashed-carrots.jpg
tags: sides, vegetables

ingredients:
- 1 can carrots
- 1 tbsp butter
- 2 tbsp parmesan cheese
- salt & pepper to taste

directions:
- Combine carrots and butter, heat through (yes, you can microwave)
- Mash carrots, adding parmesan when smooshy
- Salt and pepper how you like

---

Generally, canned carrots are stinky and not worth eating. Butter and cheese changes that.