---

layout: recipe
title:  "Red Berry Tart"
image: red-berry-tart.jpg
tags: desserts

directions:
- Bake the crust and let it cool
- Make the custard, pour into crust
- Make the red berry topping, spread over the top

components:
- Graham Cracker Crust
- Vanilla Custard Filling
- Red Berry Dessert Topping

---

A favorite when I go to BBQs (parties, hackathons, your folks' place), this red berry tart is fairly easy to make and packs a huge wow factor.