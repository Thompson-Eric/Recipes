---

layout: recipe
title:  "Pork Steaks"
image: pork-steaks.jpg
tags: mains, meat

ingredients:
- pork shoulder (or other cheap cut)
- immerison circulator (we like the [Anova](http://www.amazon.com/gp/product/B00UKPBXM4/ref=as_li_tl?ie=UTF8&camp=1789&creative=390957&creativeASIN=B00UKPBXM4&linkCode=as2&tag=repl-20&linkId=XMRXWQ35OJNCZVGE))

directions:
- Sous vide the pork at 140° for 24h
- Submerge bag into an ice bath to completely cool
- Cut and portion the cold roast into individual steaks
- Seal and save (fridge for 3 days, freezer for longer)
- To serve, reheat in bag, sear in sourching hot pan

---

Pork is called "the other white meat", but this sous vide technique is so dang good I'm gonna graduate it up to "THE white meat".