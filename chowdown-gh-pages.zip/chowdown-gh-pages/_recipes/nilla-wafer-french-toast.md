---

layout: recipe
title:  "Nilla Wafer French Toast"
image: nilla-wafer.jpg
tags: breakfast, baking

ingredients:
- 4 eggs
- 1/4 cup heavy cream
- 2 tsp vanilla 
- sprinkle of sugar
- 4 cups Nilla Wafers Minis

directions:
- Beat the eggs, heavy cream, vanilla, and sugar.
- Arrange the nillas in a few flat layers in a baking dish.
- Pour egg mixture over nillas. Let soak while oven preheats to 350°. Top with shake of cinnamon sugar.
- Bake until egg has set (it'll fluff up a bit)

---

From a weird Sunday morning when I realized we didn't have bread. Solid hitter. Served with [Treehive](https://amzn.to/2QBpGCH) Syrup, my new favorite breakfast obsession (it's mixed with honey, vanilla, and cinnamon, oof).