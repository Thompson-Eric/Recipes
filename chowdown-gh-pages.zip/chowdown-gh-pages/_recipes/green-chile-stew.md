---

layout: recipe
title:  "Green Chile Stew"
image: green-chile-stew.jpg
imagecredit: https://flic.kr/p/4CJb65
tags: sides, soups

ingredients:
- 1 jar of [green chile stew mix](http://amzn.to/1KYXSjo)
- 1lb ground chicken
- 1 red onion
- 1 green onion
- 1 can corn

directions:
- Start onions in pan, cook down
- Add chicken, corn
- Add stew mix
- Serve with croutons

---

This is a simple one, consisting of a pre-made soup mix and whatever you've got around the kitchen (or campsite). Feel free to sub/swap/switch anything in the ingredient list— anything's fair game!