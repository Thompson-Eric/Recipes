---

layout: recipe
title:  "One Minute Muffin"
image: one-minute-muffin.jpg
imagecredit: http://divaliciousrecipes.com/2012/04/26/flax-muffin-in-a-mug-in-a-minute-low-carb-and-gluten-free/
tags: breakfast

ingredients:
- 1⁄4 cup flax seed meal
- 1⁄2 teaspoon baking powder
- 1 teaspoon cinnamon
- 1 egg
- 1 teaspoon oil
- sugar to taste (or honey, stevia)

directions:
- Mix all ingredients in a coffee mug.
- Micorowave for one minute on high.

---

This flax muffin is quick, vertsatile (just mix in other goodies), and only makes one at a time, so you've got no huge tray to tempt you. Custom muffins every morning!