---
layout: post
title:  "Hot stuff! New /beta now cookin..."
author: clarklab
---

Just a quick note to say I've started work on the overhaul of the front-end templates. You can follow along at [https://chowdown.io/beta](https://chowdown.io/beta). Some highlights:

- **Mobile First.** In fact, maybe don't check it on desktop yet.
- **Tabbed View.** New bottom nav for easier jumping.
- **Books.** Aka cookbooks aka collections aka groups are coming soon.
- **Live Search.** It's been working, now it's being featured.
- **Blog**. Same. We've had one, now it has a home.

I've got a handful of other things coming soon, excited to share with y'all. Until then, happy cooking!